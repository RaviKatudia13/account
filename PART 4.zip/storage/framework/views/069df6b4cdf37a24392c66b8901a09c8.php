<?php $__env->startSection('content'); ?>
<div class="w-full max-w-md mx-auto my-16 p-8 rounded-2xl auth-card bg-white shadow-lg">
    <div class="text-center mb-6">
        <div class="inline-block p-4 mb-4 rounded-full auth-logo bg-indigo-50">
            <i class="fa-solid fa-lock fa-2x text-white-600"></i>
        </div>
        <h1 class="text-2xl font-bold auth-title mb-2">Confirm Password</h1>
        <p class="text-gray-500 auth-subtitle mb-4">This is a secure area of the application. Please confirm your password before continuing.</p>
    </div>
    <form method="POST" action="<?php echo e(route('password.confirm')); ?>" class="space-y-6">
        <?php echo csrf_field(); ?>
        <div>
            <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
            <input id="password" name="password" type="password" required autocomplete="current-password"
                   class="block w-full px-3 py-2 border rounded-md shadow-sm form-input focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                   placeholder="••••••••">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-500 text-xs mt-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="flex justify-end mt-4">
            <button type="submit"
                    class="flex justify-center w-full px-4 py-2 text-sm font-medium text-white border border-transparent rounded-md shadow-sm auth-button bg-indigo-600 hover:bg-indigo-700 transition">
                Confirm
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/auth/confirm-password.blade.php ENDPATH**/ ?>