

<?php $__env->startSection('title', 'Payment Methods'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-16">
    <h1 class="h3 mb-4 fw-bold">Payment Methods</h1>
    <a href="<?php echo e(route('admin.payment_methods.create')); ?>" class="btn btn-primary mb-3">Add Payment Method</a>
    <div class="card">
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($method->id); ?></td>
                        <td><?php echo e($method->name); ?></td>
                        <td><?php echo e($method->description); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.payment_methods.edit', $method)); ?>" class="btn btn-sm btn-warning">
                                <i class="fa-solid fa-pen"></i> 
                            </a>
                            <form action="<?php echo e(route('admin.payment_methods.destroy', $method)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/admin/payment_methods/index.blade.php ENDPATH**/ ?>