

<?php $__env->startSection('title', 'Payments'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-16">

<div class="mb-4">
    <h1 class="h3 fw-bold">Payments</h1>
    <p class="text-muted">All recorded payments</p>
    <div class="bg-white rounded shadow-sm border p-4">
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Credit/Debit</th>
                        <th>Client / Vendor / Employee</th>
                        <th>Amount</th>
                        <th>Payment Date</th>
                        <th>Payment Mode</th>
                        <th>Account</th>
                        <th>Internal Transfer</th>
                        <th>Recorded By</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                          
                        <?php echo e($payment->id); ?>

                        </td>
                        <td>
                            <?php echo e($payment->type == 1 ? 'Credit' : ($payment->type == 2 ? 'Debit' : $payment->type)); ?>

                        </td>
                        <td>
                        <?php if($payment->vendor_id): ?>
                                <?php echo e($payment->vendor->name ?? '-'); ?>

                            <?php elseif($payment->employee_id): ?>
                                <?php echo e($payment->employee->name ?? '-'); ?>

                            <?php elseif($payment->invoice_id): ?>
                                <?php echo e($payment->invoice->client->name ?? '-'); ?>

                            <?php elseif($payment->subscription_client_payment_id): ?>
                                <?php echo e($payment->subscriptionClientPayment && $payment->subscriptionClientPayment->client ? $payment->subscriptionClientPayment->client->name : '-'); ?>

                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>₹<?php echo e(number_format($payment->amount, 2)); ?></td>
                        <td><?php echo e($payment->payment_date); ?></td>
                        <td><?php echo e($payment->paymentMethod->name ?? '-'); ?></td>
                        <td>
                            <?php if($payment->account && is_object($payment->account)): ?>
                                <?php echo e($payment->account->display_name); ?>

                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($payment->internal_transfer): ?>
                                <span class="badge bg-info">Yes</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">No</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($payment->recordedByUser->name ?? $payment->recorded_by); ?></td>
                        <td><?php echo e($payment->remarks ?: '-'); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/admin/payments.blade.php ENDPATH**/ ?>