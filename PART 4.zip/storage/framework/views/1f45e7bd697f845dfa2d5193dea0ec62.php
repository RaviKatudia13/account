<?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="admin-body min-h-screen" x-data="{ sidebarOpen: true }">
    <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="flex min-h-screen h-screen">
        <div class="left-sidebar-container h-screen overflow-y-auto">
            <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="mobile-menu-overlay" id="mobileMenuOverlay"></div>
        <main class="main-content" style="overflow-y:auto; max-height:100vh;">
            
            <?php if(session('success')): ?>
                <div class="alert alert-success mt-16" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger mt-16" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger mt-16" role="alert">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            HSStaticMethods.autoInit();
            
            // Mobile menu functionality
            const mobileMenuToggle = document.getElementById('mobileMenuToggle');
            const sidebarContainer = document.querySelector('.left-sidebar-container');
            const mobileMenuOverlay = document.getElementById('mobileMenuOverlay');
            
            if (mobileMenuToggle) {
                mobileMenuToggle.addEventListener('click', function() {
                    sidebarContainer.classList.toggle('show');
                    mobileMenuOverlay.classList.toggle('show');
                    document.body.classList.toggle('menu-open');
                });
            }
            
            if (mobileMenuOverlay) {
                mobileMenuOverlay.addEventListener('click', function(e) {
                    if (e.target === mobileMenuOverlay) {
                        sidebarContainer.classList.remove('show');
                        mobileMenuOverlay.classList.remove('show');
                        document.body.classList.remove('menu-open');
                    }
                });
            }
            
            // Close mobile menu on window resize
            window.addEventListener('resize', function() {
                if (window.innerWidth > 1200) {
                    sidebarContainer.classList.remove('show');
                    mobileMenuOverlay.classList.remove('show');
                    document.body.classList.remove('menu-open');
                }
            });

            // Auto-hide alerts after 5 seconds
            setTimeout(function () {
                let alerts = document.querySelectorAll('.alert');
                alerts.forEach(function(alert) {
                    alert.style.transition = 'opacity 0.5s';
                    alert.style.opacity = 0;
                    setTimeout(() => alert.remove(), 750);
                });
            }, 5000);
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/layouts/admin.blade.php ENDPATH**/ ?>