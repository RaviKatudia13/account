<div class="modal fade" id="addPaymentModal<?php echo e($employee->id); ?>" tabindex="-1" aria-labelledby="addPaymentModalLabel<?php echo e($employee->id); ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addPaymentModalLabel<?php echo e($employee->id); ?>">Add Payment for <?php echo e($employee->name); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('admin.employee.payments.store', $employee->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="amount<?php echo e($employee->id); ?>" class="form-label">Amount</label>
                        <input type="number" step="0.01" name="amount" id="amount<?php echo e($employee->id); ?>" class="form-control" required max="<?php echo e($employee->total_remaining_amount); ?>">
                        <div class="form-text">Max: <?php echo e(number_format($employee->total_remaining_amount, 2)); ?></div>
                    </div>
                    <div class="mb-3">
                        <label for="payment_date<?php echo e($employee->id); ?>" class="form-label">Payment Date</label>
                        <input type="date" name="payment_date" id="payment_date<?php echo e($employee->id); ?>" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="description<?php echo e($employee->id); ?>" class="form-label">Description</label>
                        <textarea name="description" id="description<?php echo e($employee->id); ?>" class="form-control" rows="2"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="payment_mode<?php echo e($employee->id); ?>" class="form-label">Payment Mode</label>
                        <select name="payment_mode" id="payment_mode<?php echo e($employee->id); ?>" class="form-control payment-mode-select" required onchange="filterAccountsByPaymentMode(this, '<?php echo e($employee->id); ?>')">
                            <option value="">Select payment mode</option>
                            <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($method->id); ?>"><?php echo e($method->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="account_id<?php echo e($employee->id); ?>" class="form-label">Account</label>
                        <select name="account_id" id="account-select-<?php echo e($employee->id); ?>" class="form-control" required>
                            <option value="">Select account</option>
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($account->id); ?>" data-payment-mode="<?php echo e($account->payment_mode_id); ?>"><?php echo e($account->display_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
function filterAccountsByPaymentMode(select, id) {
    var mode = select.value;
    var accountSelect = document.getElementById('account-select-' + id);
    Array.from(accountSelect.options).forEach(function(option) {
        if (!option.value) { option.style.display = ''; return; }
        option.style.display = (option.getAttribute('data-payment-mode') === mode) ? '' : 'none';
    });
    accountSelect.value = '';
}
</script> <?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/admin/employee/_add_payment_modal.blade.php ENDPATH**/ ?>