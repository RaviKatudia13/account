

<?php $__env->startSection('title', 'Internal Transfer List'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $totalAmount = $transfers->sum('amount');
    // Debug: Show account count
    echo "<!-- Debug: Total accounts passed to view: " . $accounts->count() . " -->";
?>
<div class="container mt-16">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h3 mb-0 fw-bold">Internal Transfer List</h1>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTransferModal">+ Add Internal Transfer</button>
    </div>
    
    
    <!-- Add Internal Transfer Modal -->
    <div class="modal fade" id="addTransferModal" tabindex="-1" aria-labelledby="addTransferModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addTransferModalLabel">Add Internal Transfer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="<?php echo e(route('admin.internal-transfer.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="debit_account" class="form-label">Debit Account</label>
                            <select class="form-control" id="debit_account" name="debit_account" required>
                                <option value="">Select Debit Account</option>
                                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($account->name); ?>"><?php echo e($account->display_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <!-- Debug: <?php echo e($accounts->count()); ?> accounts available -->
                            <!-- Debug accounts: <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($acc->name); ?>, <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                            <?php $__errorArgs = ['debit_account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="credit_account" class="form-label">Credit Account</label>
                            <select class="form-control" id="credit_account" name="credit_account" required>
                                <option value="">Select Credit Account</option>
                                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($account->name); ?>"><?php echo e($account->display_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <!-- Debug: <?php echo e($accounts->count()); ?> accounts available -->
                            <!-- Debug accounts: <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($acc->name); ?>, <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                            <?php $__errorArgs = ['credit_account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="amount" class="form-label">Amount</label>
                            <input type="number" step="0.01" class="form-control" id="amount" name="amount" value="<?php echo e(old('amount')); ?>" required>
                            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="2"><?php echo e(old('description')); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Transfer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body responsive-table">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Account</th>
                        <th>Total Credit</th>
                        <th>Total Debit</th>
                        <th>Balance</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $totalCredit = $transfers->where('credit_account', $account->name)->sum('amount');
                            $totalDebit = $transfers->where('debit_account', $account->name)->sum('amount');
                            $balance = $totalCredit - $totalDebit;
                        ?>
                        <tr>
                            <td><?php echo e($account->display_name); ?></td>
                            <td class="text-success">₹<?php echo e(number_format($totalCredit, 2)); ?></td>
                            <td class="text-danger">₹<?php echo e(number_format($totalDebit, 2)); ?></td>
                            <td class="<?php echo e($balance >= 0 ? 'text-success' : 'text-danger'); ?>">
                                ₹<?php echo e(number_format($balance, 2)); ?>

                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#historyModal<?php echo e(md5($account->name)); ?>">
                                    <i class="fa fa-eye"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="mt-3">
                <strong>Total Amount:</strong> ₹<?php echo e(number_format($totalAmount, 2)); ?>

            </div>
        </div>
    </div>
</div>
<!-- Render all modals after the table -->
<?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="historyModal<?php echo e(md5($account->name)); ?>" tabindex="-1" aria-labelledby="historyModalLabel<?php echo e(md5($account->name)); ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="historyModalLabel<?php echo e(md5($account->name)); ?>">History for <?php echo e($account->display_name); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Debit/Credit</th>
                            <th>Counterparty</th>
                            <th>Amount</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $hasHistory = false; ?>
                        <?php $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($t->debit_account === $account->name || $t->credit_account === $account->name): ?>
                                <?php $hasHistory = true; ?>
                                <tr>
                                    <td><?php echo e($t->created_at ? $t->created_at->format('Y-m-d') : '-'); ?></td>
                                    <td>
                                        <?php if($t->debit_account === $account->name): ?>
                                            <span class="text-danger">Debit</span>
                                        <?php else: ?>
                                            <span class="text-success">Credit</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($t->debit_account === $account->name): ?>
                                            <?php echo e($t->credit_account); ?>

                                        <?php else: ?>
                                            <?php echo e($t->debit_account); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($t->debit_account === $account->name): ?>
                                            -₹<?php echo e(number_format($t->amount, 2)); ?>

                                        <?php else: ?>
                                            +₹<?php echo e(number_format($t->amount, 2)); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($t->description); ?></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$hasHistory): ?>
                            <tr>
                                <td colspan="5" class="text-center">No transactions for this account.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/admin/internal_transfer/list.blade.php ENDPATH**/ ?>