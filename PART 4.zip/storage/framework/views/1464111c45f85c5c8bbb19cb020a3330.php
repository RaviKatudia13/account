<!-- Header Partial -->
<div class="app-topstrip">
    <div class="header-left">
        <!-- Mobile Menu Toggle Button -->
        <button type="button" class="mobile-menu-toggle" id="mobileMenuToggle" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>
        <div class="header-logo-container">
            <a href="" class="header-logo">
                <span>
                    Welcome back! <?php echo e(ucfirst(substr(auth()->user()->name, 0 ))); ?>

                </span>
            </a>
        </div>
    </div>
    <div class="header-right">
        <?php if(auth()->guard()->check()): ?>
        <div class="header-dropdown dropdown">
            <div class="user-info" onclick="this.parentElement.classList.toggle('open')">
                <div class="user-avatar">
                    <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

                </div>
                <div class="user-details">
                    <div class="user-name"><?php echo e(auth()->user()->name); ?></div>
                    <div class="user-role">Administrator</div>
                </div>
                <i class="fas fa-chevron-down dropdown-arrow"></i>
            </div>
            <div class="dropdown-menu">
                <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item">
                    <i class="fas fa-user-edit"></i>
                    Edit Profile
                </a>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="dropdown-item-form">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="dropdown-item logout-dropdown-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Close header dropdown when clicking outside
window.addEventListener('click', function(e) {
    const headerDropdown = document.querySelector('.header-dropdown');
    if (headerDropdown && !headerDropdown.contains(e.target)) {
        headerDropdown.classList.remove('open');
    }
});
</script><?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>