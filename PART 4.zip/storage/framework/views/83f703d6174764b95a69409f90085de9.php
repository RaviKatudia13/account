

<?php $__env->startSection('title', 'Accounts'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-16">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h3 mb-0 fw-bold">Accounts</h1>
        <a href="<?php echo e(route('admin.accounts.create')); ?>" class="btn btn-primary">+ Add Account</a>
    </div>

    <div class="card">
        <div class="card-body responsive-table">
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Payment Mode</th>
                            <th>Account Number/UPI ID</th>
                            <th>Bank Name</th>
                            <th>Holder Name</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($account->name); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($account->type === 'bank' ? 'primary' : ($account->type === 'upi' ? 'success' : 'warning')); ?>">
                                    <?php echo e(ucfirst($account->type)); ?>

                                </span>
                            </td>
                            <td><?php echo e($account->paymentMethod->name ?? '-'); ?></td>
                            <td>
                                <?php if($account->type === 'bank'): ?>
                                    <?php echo e($account->account_number ?? '-'); ?>

                                <?php elseif($account->type === 'upi'): ?>
                                    <?php echo e($account->upi_id ?? '-'); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($account->bank_name ?? '-'); ?></td>
                            <td><?php echo e($account->holder_name ?? '-'); ?></td>
                            <td>
                                <?php if($account->is_active): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.accounts.edit', $account)); ?>" class="btn btn-sm btn-primary">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <form method="POST" action="<?php echo e(route('admin.accounts.destroy', $account)); ?>" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this account?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/admin/accounts/index.blade.php ENDPATH**/ ?>