

<?php $__env->startSection('content'); ?>
<div class="container mt-16">
    <h1 class="h3 mb-4 fw-bold">Subscription Client Payments</h1>
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addPaymentModal">
        Add Payment
    </button>
    <div class="card">
        <div class="card-body responsive-table">
        <table class="table table-bordered table-striped">
            <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Client</th>
                        <th scope="col">Invoice #</th>
                        <th scope="col">Start Date</th>
                        <th scope="col">End Date</th>
                        <th scope="col">Total</th>
                        <th scope="col">Paid Amount</th>
                        <th scope="col">Remain Amount</th>
                        <th scope="col">Status</th>
                        <th scope="col">Description</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($payments) && count($payments)): ?>
                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($payment->id ?? '-'); ?></td>
                            <td>
                                <?php echo e($payment->client && $payment->client->name ? $payment->client->name : '-'); ?>

                            </td>
                            <td><?php echo e($payment->invoice_number ?? '-'); ?></td>
                            <td><?php echo e($payment->start_date ? \Carbon\Carbon::parse($payment->start_date)->format('d-M-Y') : '-'); ?></td>
                            <td><?php echo e($payment->end_date ? \Carbon\Carbon::parse($payment->end_date)->format('d-M-Y') : '-'); ?></td>
                            <td>
                                <?php echo e(is_numeric($payment->total) ? number_format($payment->total, 2) : '-'); ?>

                            </td>
                            <td><?php echo e(is_numeric($payment->paid_amount) ? number_format($payment->paid_amount, 2) : '0.00'); ?></td>
                            <td><?php echo e((is_numeric($payment->total) && is_numeric($payment->paid_amount)) ? number_format($payment->total - $payment->paid_amount, 2) : '0.00'); ?></td>
                            <td>
                                <?php if($payment->status === 'Paid'): ?>
                                    <span class="badge bg-success">Paid</span>
                                <?php elseif($payment->status === 'Partial'): ?>
                                    <span class="badge bg-warning text-dark">Partial</span>
                                <?php elseif($payment->status === 'Due'): ?>
                                    <span class="badge bg-danger">Due</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo e($payment->status ?? '-'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($payment->description ?? '-'); ?></td>
                            <td>
                                <div class="table-action-btn-group">
                                    <button class="btn btn-sm btn-primary" title="View Payment" data-bs-toggle="modal" data-bs-target="#viewPaymentModal<?php echo e($payment->id); ?>">
                                        <i class="fa fa-eye"></i>
                                    </button>
                                    <?php if(($payment->total - $payment->paid_amount) > 0): ?>
                                        <button class="btn btn-sm btn-success" title="Do Payment" data-bs-toggle="modal" data-bs-target="#payPaymentModal<?php echo e($payment->id); ?>">
                                            <i class="fa fa-credit-card"></i>
                                        </button>
                                    <?php endif; ?>
                                    <form action="#" method="POST" style="display:inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')" title="Delete Payment">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="12" class="text-center">No payments found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <?php if(isset($payments)): ?>
                <div class="d-flex justify-content-center mt-3">
                    <?php echo e($payments->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php echo $__env->make('admin.subscription_client_payments.modals.create-invoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(isset($payments) && count($payments)): ?>
    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('admin.subscription_client_payments.modals.view-details-invoice', ['payment' => $payment], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.subscription_client_payments.modals.pay-invoice', ['payment' => $payment], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/admin/subscription_client_payments/index.blade.php ENDPATH**/ ?>