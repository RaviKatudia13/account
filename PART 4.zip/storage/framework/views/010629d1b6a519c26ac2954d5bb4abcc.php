

<div class="modal fade" id="payPaymentModal<?php echo e($payment->id); ?>" tabindex="-1" aria-labelledby="payPaymentModalLabel<?php echo e($payment->id); ?>" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="payPaymentModalLabel<?php echo e($payment->id); ?>">Record Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo $__env->make('admin.subscription_client_payments.modals._pay-invoice-body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/admin/subscription_client_payments/modals/pay-invoice.blade.php ENDPATH**/ ?>