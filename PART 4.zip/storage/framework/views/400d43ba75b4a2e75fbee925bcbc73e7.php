<div class="modal fade" id="viewPaymentModal<?php echo e($payment->id); ?>" tabindex="-1" aria-labelledby="viewPaymentModalLabel<?php echo e($payment->id); ?>" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewPaymentModalLabel<?php echo e($payment->id); ?>">Client Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <p><strong>Name:</strong> <?php echo e($payment->client && $payment->client->name ? $payment->client->name : '-'); ?></p>
                        <p><strong>Company:</strong> <?php echo e($payment->client && $payment->client->company_name ? $payment->client->company_name : '-'); ?></p>
                        <p><strong>Mobile:</strong> <?php echo e($payment->client && $payment->client->mobile ? $payment->client->mobile : '-'); ?></p>
                        <p><strong>Email:</strong> <?php echo e($payment->client && $payment->client->email ? $payment->client->email : '-'); ?></p>
                    </div>
                    <div class="col-12 col-md-6">
                        <p><strong>Address:</strong> <?php echo e($payment->client && $payment->client->address ? $payment->client->address : '-'); ?></p>
                        <p><strong>GST Registered:</strong> <?php echo e($payment->client && $payment->client->gst_registered ? 'Yes' : 'No'); ?></p>
                        <p><strong>GSTIN:</strong> <?php echo e($payment->client && $payment->client->gstin ? $payment->client->gstin : '-'); ?></p>
                        <p><strong>Payment Mode:</strong> <?php echo e($payment->client && $payment->client->payment_mode ? $payment->client->payment_mode : '-'); ?></p>
                    </div>
                </div>
                <div class="mt-4">
                    <h6>Payment History</h6>
                    <table class="table table-sm table-bordered">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Payment Mode</th>
                                <th>Account</th>
                                <th>Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = \App\Models\Payment::where('subscription_client_payment_id', $payment->id)->orderBy('payment_date')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($history->payment_date); ?></td>
                                    <td><?php echo e(number_format($history->amount, 2)); ?></td>
                                    <td><?php echo e($history->paymentMethod->name ?? '-'); ?></td>
                                    <td><?php echo e($history->account->display_name ?? '-'); ?></td>
                                    <td><?php echo e($history->remarks); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div> <?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/admin/subscription_client_payments/modals/view-details-invoice.blade.php ENDPATH**/ ?>