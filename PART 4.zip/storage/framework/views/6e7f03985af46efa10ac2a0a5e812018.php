<?php $__env->startSection('content'); ?>
<div class="w-full max-w-3xl mx-auto my-12 p-8 rounded-2xl auth-card bg-white shadow-lg space-y-8">
    <div class="text-center mb-6">
        <div class="inline-block p-4 mb-4 rounded-full auth-logo bg-indigo-50">
            <i class="fa-solid fa-user fa-2x text-indigo-600"></i>
        </div>
        <h1 class="text-3xl font-bold auth-title">Edit Profile</h1>
        <p class="mt-2 auth-subtitle">Manage your account information, password, and security.</p>
    </div>
    <div class="space-y-8">
        <div>
            <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div>
            <?php echo $__env->make('profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div>
            <?php echo $__env->make('profile.partials.delete-user-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="p-6 bg-gray-50 rounded shadow">
            <h3 class="text-lg font-semibold mb-4">Two-Factor Authentication</h3>
            <?php if(auth()->user()->two_factor_secret): ?>
                <p class="mb-2 text-green-600">Two-factor authentication is <strong>enabled</strong> on your account.</p>
                <form method="POST" action="<?php echo e(url('user/two-factor-authentication')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded">Disable 2FA</button>
                </form>
                <div class="mt-4">
                    <h4 class="font-semibold">Recovery Codes</h4>
                    <ul class="list-disc ml-6">
                        <?php $__currentLoopData = json_decode(decrypt(auth()->user()->two_factor_recovery_codes), true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($code); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php else: ?>
                <p class="mb-2 text-yellow-600">Two-factor authentication is <strong>not enabled</strong> on your account.</p>
                <form method="POST" action="<?php echo e(url('user/two-factor-authentication')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Enable 2FA</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/profile/edit.blade.php ENDPATH**/ ?>