<?php $__env->startPush('head'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title', 'Invoices'); ?>

<?php $__env->startSection('content'); ?>
<!-- Debug Information -->
<!-- <div class="alert alert-info">
    <strong>Debug Info:</strong><br>
    Total Invoices: <?php echo e($invoices->count()); ?><br>
    Invoices Collection: <?php echo e($invoices->toJson()); ?>

</div> -->

<div class="mb-4 mt-16">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 fw-bold">Invoices</h1>
            <p class="text-muted">Manage your invoice billing and payments</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-secondary">
                <i class="fas fa-users"></i> View Clients
            </a>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addInvoiceModal">
                <i class="fas fa-plus"></i> New Invoice
            </button>
        </div>
    </div>

    <div class="bg-white rounded shadow-sm border p-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <input type="text" placeholder="🔍 Search invoices..." class="form-control w-50">
            <div class="btn-group">
                <button class="btn btn-sm btn-outline-secondary">All</button>
                <button class="btn btn-sm btn-outline-secondary">Paid</button>
                <button class="btn btn-sm btn-outline-secondary">Due</button>
            </div>
        </div>
        <div class="table-responsive responsive-table">
            <table class="table table-striped align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Invoice No</th>
                        <th>Date</th>
                        <th>Client</th>
                        <th>Total Amount</th>
                        <th>Paid Amount</th>
                        <th>Remaining</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $totalPaid = $inv->payments()->sum('amount');
                        $remainingAmount = $inv->total - $totalPaid;
                    ?>
                    <tr>
                        <td class="fw-semibold">
                            <?php echo e(str_pad($inv->id, 7, '2025', STR_PAD_LEFT)); ?>

                        </td>
                        <td><i class="far fa-calendar-alt text-gray-400"></i> <?php echo e(\Carbon\Carbon::parse($inv->invoice_date)->format('d/m/Y')); ?></td>
                        <td><?php echo e($inv->client ? ($inv->client->name ?? $inv->client->name) : 'No Client'); ?></td>
                        <td>₹<?php echo e(number_format($inv->total, 2)); ?></td>
                        <td>₹<?php echo e(number_format($totalPaid, 2)); ?></td>
                        <td>
                            <?php if($remainingAmount > 0): ?>
                                <span class="text-danger fw-semibold">₹<?php echo e(number_format($remainingAmount, 2)); ?></span>
                            <?php else: ?>
                                <span class="text-success fw-semibold">₹0.00</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($inv->status=='Paid'): ?>
                                <span class="badge bg-success">Paid</span>
                            <?php elseif($inv->status=='Partial'): ?>
                                <span class="badge bg-warning text-dark">Partial</span>
                            <?php elseif($inv->status=='Due'): ?>
                                <span class="badge bg-danger">Due</span>
                            <?php else: ?>
                                <span class="badge bg-secondary"><?php echo e($inv->status); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#viewInvoiceModal<?php echo e($inv->id); ?>"><i class="fa-solid fa-eye"></i></button>
                            <?php if($remainingAmount > 0): ?>
                            <button class="btn btn-sm btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#payInvoiceModal<?php echo e($inv->id); ?>"><i class="fa-solid fa-money-check-alt"></i></button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- View Invoice Modals -->
    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $totalPaid = $inv->payments()->sum('amount');
        $remainingAmount = $inv->total - $totalPaid;
    ?>
    <div class="modal fade" id="viewInvoiceModal<?php echo e($inv->id); ?>" tabindex="-1" aria-labelledby="viewInvoiceModalLabel<?php echo e($inv->id); ?>" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewInvoiceModalLabel<?php echo e($inv->id); ?>">Invoice Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Invoice Information</h6>
                            <p><strong>Invoice No:</strong> <?php echo e($inv->invoice_number); ?></p>
                            <p><strong>Client:</strong> <?php echo e($inv->client ? ($inv->client->name ?? $inv->client->name) : 'No Client'); ?></p>
                            <p><strong>Date:</strong> <?php echo e(\Carbon\Carbon::parse($inv->invoice_date)->format('d/m/Y')); ?></p>
                            <p><strong>Total Amount:</strong> ₹<?php echo e(number_format($inv->total, 2)); ?></p>
                            <p><strong>Status:</strong> 
                                <?php if($inv->status=='Paid'): ?>
                                    <span class="badge bg-success">Paid</span>
                                <?php elseif($inv->status=='Partial'): ?>
                                    <span class="badge bg-warning text-dark">Partial</span>
                                <?php elseif($inv->status=='Due'): ?>
                                    <span class="badge bg-danger">Due</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo e($inv->status); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <h6>Payment Summary</h6>
                            <p><strong>Total Paid:</strong> ₹<?php echo e(number_format($totalPaid, 2)); ?></p>
                            <p><strong>Remaining Balance:</strong> 
                                <?php if($remainingAmount > 0): ?>
                                    <span class="text-danger fw-semibold">₹<?php echo e(number_format($remainingAmount, 2)); ?></span>
                                <?php else: ?>
                                    <span class="text-success fw-semibold">₹0.00</span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                    
                    <?php if($inv->payments->count() > 0): ?>
                    <div class="mt-4">
                        <h6>Payment History</h6>
                        <div class="table-responsive">
                            <table class="table table-sm table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Mode</th>
                                        <th>Recorded By</th>
                                        <th>Remarks</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $inv->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(\Carbon\Carbon::parse($payment->payment_date)->format('d/m/Y')); ?></td>
                                        <td>₹<?php echo e(number_format($payment->amount, 2)); ?></td>
                                        <td><?php echo e($payment->paymentMethod->name ?? '-'); ?></td>
                                        <td><?php echo e(optional($payment->recordedByUser)->name ?? '-'); ?></td>
                                        <td><?php echo e($payment->remarks ?? '-'); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Pay Invoice Modals -->
    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $totalPaid = $inv->payments()->sum('amount');
        $remainingAmount = $inv->total - $totalPaid;
    ?>
    <div class="modal fade" id="payInvoiceModal<?php echo e($inv->id); ?>" tabindex="-1" aria-labelledby="payInvoiceModalLabel<?php echo e($inv->id); ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="payInvoiceModalLabel<?php echo e($inv->id); ?>">Record Payment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info">
                        <strong>Invoice Total:</strong> ₹<?php echo e(number_format($inv->total, 2)); ?><br>
                        <strong>Already Paid:</strong> ₹<?php echo e(number_format($totalPaid, 2)); ?><br>
                        <strong>Remaining Balance:</strong> ₹<?php echo e(number_format($remainingAmount, 2)); ?>

                    </div>
                    <form method="POST" action="<?php echo e(route('admin.invoices.pay', $inv->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label">Payment Amount (₹)</label>
                            <input type="number" name="amount" class="form-control" step="0.01" max="<?php echo e($remainingAmount); ?>" required>
                            <div class="form-text">Maximum payment amount: ₹<?php echo e(number_format($remainingAmount, 2)); ?></div>
                            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Payment Date</label>
                            <input type="date" name="payment_date" class="form-control" value="<?php echo e(now()->format('Y-m-d')); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Payment Mode</label>
                            <select name="payment_mode" id="payment_mode" class="form-select" required>
                                <option value="">Select payment mode</option>
                                <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($method->id); ?>"><?php echo e($method->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Account</label>
                            <select name="account_id" id="account_select" class="form-select" required>
                                <option value="">Select account</option>
                                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($account->id); ?>" data-payment-mode="<?php echo e($account->payment_mode_id); ?>"><?php echo e($account->display_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Remarks</label>
                            <textarea name="remarks" rows="3" class="form-control" placeholder="Enter additional details (optional)"></textarea>
                        </div>
                        <div class="d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Record Payment</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Payments Table (below the invoices table) -->
    <!-- <?php if(isset($payments) && count($payments)): ?>
    <div class="mt-5">
        <h4>Payments</h4>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Invoice No</th>
                        <th>Client</th>
                        <th>Amount</th>
                        <th>Payment Date</th>
                        <th>Payment Mode</th>
                        <th>Account</th>
                        <th>Recorded By</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($payment->invoice->invoice_number ?? ''); ?></td>
                        <td><?php echo e($payment->invoice && $payment->invoice->client ? ($payment->invoice->client->company_name ?? $payment->invoice->client->name) : 'No Client'); ?></td>
                        <td>₹<?php echo e(number_format($payment->amount, 2)); ?></td>
                        <td><?php echo e($payment->payment_date); ?></td>
                        <td><?php echo e($payment->payment_mode); ?></td>
                        <td><?php echo e($payment->account); ?></td>
                        <td><?php echo e($payment->recorded_by); ?></td>
                        <td><?php echo e($payment->remarks ?: '-'); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?> -->

    <!-- Add Invoice Modal -->
    <div class="modal fade" id="addInvoiceModal" tabindex="-1" aria-labelledby="addInvoiceModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addInvoiceModalLabel">Create New Invoice</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php echo $__env->make('admin.invoices.modals._create-invoice-body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Filter accounts based on payment mode selection
document.addEventListener('DOMContentLoaded', function() {
    const paymentModeSelect = document.getElementById('payment_mode');
    const accountSelect = document.getElementById('account_select');
    
    if (paymentModeSelect && accountSelect) {
        paymentModeSelect.addEventListener('change', function() {
            const selectedPaymentMode = this.value;
            const accountOptions = accountSelect.querySelectorAll('option');
            
            // Reset account selection
            accountSelect.value = '';
            
            // Show/hide account options based on payment mode
            accountOptions.forEach(option => {
                if (option.value === '') {
                    // Keep the "Select account" option always visible
                    option.style.display = 'block';
                } else {
                    const accountPaymentMode = option.getAttribute('data-payment-mode');
                    if (selectedPaymentMode === '' || accountPaymentMode === selectedPaymentMode) {
                        option.style.display = 'block';
                    } else {
                        option.style.display = 'none';
                    }
                }
            });
        });
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/admin/invoices/index.blade.php ENDPATH**/ ?>