

<?php $__env->startSection('title', 'Edit Client Category'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1 class="h3 mb-4">Edit Client Category</h1>
    <form method="POST" action="<?php echo e(route('admin.categories.update', $category)); ?>" style="max-width:400px;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Category Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $category->name)); ?>" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="btn btn-primary" type="submit">Update Category</button>
        <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-secondary ms-2">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/admin/categories_edit.blade.php ENDPATH**/ ?>