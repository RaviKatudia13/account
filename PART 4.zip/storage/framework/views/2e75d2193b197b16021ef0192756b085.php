
<h2 class="text-lg font-semibold mb-1">Record Payment</h2>

<form class="space-y-4 text-sm" method="POST" action="<?php echo e(route('admin.subscription-client-payments.record-payment', $payment->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php
        $remainAmount = (is_numeric($payment->total) && is_numeric($payment->paid_amount))
            ? $payment->total - $payment->paid_amount
            : 0;
    ?>
    <div>
        <label class="block text-sm font-medium mb-1">Amount (₹)</label>
        <input
            type="number"
            name="amount"
            placeholder="Enter amount"
            class="w-full border rounded px-3 py-2 text-sm"
            max="<?php echo e($remainAmount); ?>"
            step="0.01"
            required
            oninput="validateMaxAmount(this, <?php echo e($remainAmount); ?>)"
        />
        <div class="text-xs text-gray-500 mt-1">
            Max allowed: ₹<?php echo e(number_format($remainAmount, 2)); ?>

        </div>
        <div id="amount-error-<?php echo e($payment->id); ?>" class="text-xs text-danger mt-1" style="display:none;">
            Amount cannot exceed max allowed.
        </div>
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Payment Date</label>
        <input type="date" name="payment_date" value="<?php echo e(now()->format('Y-m-d')); ?>" class="w-full border rounded px-3 py-2 text-sm" required />
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Payment Mode</label>
        <select name="payment_mode_id" class="w-full border rounded px-3 py-2 text-sm payment-mode-select" required onchange="filterAccountsByPaymentMode(this, '<?php echo e($payment->id); ?>')">
            <option value="">Select payment mode</option>
            <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($method->id); ?>"><?php echo e($method->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Account</label>
        <select name="account_id" id="account-select-<?php echo e($payment->id); ?>" class="w-full border rounded px-3 py-2 text-sm" required>
            <option value="">Select account</option>
            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($account->id); ?>" data-payment-mode="<?php echo e($account->payment_mode_id); ?>"><?php echo e($account->display_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Remarks</label>
        <textarea name="remarks" rows="3" placeholder="Enter additional details (optional)" class="w-full border rounded px-3 py-2 text-sm"></textarea>
    </div>
    <div class="flex justify-end gap-2">
        <button type="button" class="px-4 py-2 border rounded-md text-sm" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700">Record Payment</button>
    </div>
</form>

<script>
function validateMaxAmount(input, max) {
    const errorDiv = document.getElementById('amount-error-<?php echo e($payment->id); ?>');
    if (parseFloat(input.value) > max) {
        input.value = max;
        errorDiv.style.display = 'block';
    } else {
        errorDiv.style.display = 'none';
    }
}

function filterAccountsByPaymentMode(select, paymentId) {
    var mode = select.value;
    var accountSelect = document.getElementById('account-select-' + paymentId);
    Array.from(accountSelect.options).forEach(function(option) {
        if (!option.value) { option.style.display = ''; return; }
        option.style.display = (option.getAttribute('data-payment-mode') === mode) ? '' : 'none';
    });
    accountSelect.value = '';
}
</script>
<?php /**PATH C:\xampp\htdocs\Laravel\admin_panel\resources\views/admin/subscription_client_payments/modals/_pay-invoice-body.blade.php ENDPATH**/ ?>