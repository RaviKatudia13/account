{{-- resources/views/invoices/modals/pay-invoice.blade.php --}}

<div
    x-show="paymentModal"
    x-transition
    x-cloak
    class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm px-4 py-6"
>
    <div @click.away="paymentModal = false" class="bg-white rounded-xl shadow-xl max-w-md w-full p-6 relative">
        <!-- Close Button -->
        <button @click="paymentModal = false" class="absolute top-3 right-4 text-gray-500 hover:text-red-500 text-lg">
            &times;
        </button>

        @include('admin.invoices.modals._pay-invoice-body')
    </div>
</div>